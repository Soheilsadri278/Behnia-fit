<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>صفحه پیدا نشد | بهنیا فیت</title>
  <meta name="robots" content="noindex, follow" />
  <meta name="theme-color" content="#f7f4ee" />
  <link rel="icon" type="image/png" sizes="64x64" href="<?php echo esc_url( BF_THEME_URI ); ?>/assets/img/favicon.png" />
  <style>
    *,*::before,*::after{box-sizing:border-box}
    body{margin:0;min-height:100vh;display:grid;place-items:center;padding:2rem 1.25rem;
      background:#f7f4ee;color:#14150f;text-align:center;
      font-family:"Vazirmatn","Segoe UI",Tahoma,sans-serif;line-height:1.85}
    img{max-width:100%}
    .box{max-width:32rem}
    .mark{width:96px;height:auto;margin-bottom:1.75rem;opacity:.95}
    .code{font-size:.78rem;letter-spacing:.22em;color:#8a8f7d;font-weight:600}
    h1{font-size:clamp(1.5rem,1.1rem+1.6vw,2.15rem);line-height:1.4;margin:.6rem 0 0;color:#14234b}
    p{color:#5b6068;margin:.9rem 0 0}
    a{display:inline-block;margin-top:1.9rem;padding:.9rem 1.9rem;border-radius:100px;
      background:#14234b;color:#fff;text-decoration:none;font-weight:700;font-size:.95rem}
    a:hover{background:#0d1936}
  </style>
  <?php wp_head(); ?>
</head>
<?php bf_body_tag(); ?>
  <div class="box">
    <img class="mark" src="<?php echo esc_url( BF_THEME_URI ); ?>/assets/img/logo-mark.png" alt="" width="400" height="231" />
    <div class="code">۴۰۴</div>
    <h1>این صفحه پیدا نشد.</h1>
    <p>ممکن است نشانی را اشتباه وارد کرده باشید یا صفحه جابه‌جا شده باشد.</p>
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">بازگشت به صفحهٔ اصلی</a>
  </div>
  <?php wp_footer(); ?>
</body>
</html>
